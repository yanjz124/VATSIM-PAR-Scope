using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

class Program
{
    delegate bool EnumResNameProc(IntPtr hModule, IntPtr lpszType, IntPtr lpszName, IntPtr lParam);

    [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
    static extern IntPtr LoadLibraryEx(string lpFileName, IntPtr hFile, uint dwFlags);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool FreeLibrary(IntPtr hModule);
    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool EnumResourceNames(IntPtr hModule, IntPtr lpszType, EnumResNameProc lpEnumFunc, IntPtr lParam);

    const uint LOAD_LIBRARY_AS_DATAFILE = 0x00000002;

    static IntPtr MAKEINTRESOURCE(int id)
    {
        return new IntPtr(id);
    }

    static bool Callback(IntPtr hModule, IntPtr lpszType, IntPtr lpszName, IntPtr lParam)
    {
        var list = (List<string>)GCHandle.FromIntPtr(lParam).Target;
        string name;
        if (((ulong)lpszName >> 16) == 0)
        {
            // integer resource id
            int id = lpszName.ToInt32();
            name = "#" + id;
        }
        else
        {
            name = Marshal.PtrToStringUni(lpszName);
        }
        list.Add(name);
        return true; // continue
    }

    static List<string> EnumNames(IntPtr hModule, IntPtr type)
    {
        var results = new List<string>();
        var gch = GCHandle.Alloc(results);
        try
        {
            EnumResourceNames(hModule, type, Callback, GCHandle.ToIntPtr(gch));
        }
        catch (Exception ex)
        {
            Console.WriteLine("EnumResourceNames failed: " + ex.Message);
        }
        finally
        {
            if (gch.IsAllocated) gch.Free();
        }
        return results;
    }

    static void Main(string[] args)
    {
        if (args.Length == 0) { Console.WriteLine("Usage: ResEnum <exe-or-dll>"); return; }
        string path = args[0];
        IntPtr h = LoadLibraryEx(path, IntPtr.Zero, LOAD_LIBRARY_AS_DATAFILE);
        if (h == IntPtr.Zero)
        {
            Console.WriteLine("LoadLibraryEx failed, err=" + Marshal.GetLastWin32Error());
            return;
        }
        try
        {
            Console.WriteLine("Loaded: " + path);
            var groupIcons = EnumNames(h, MAKEINTRESOURCE(14));
            var icons = EnumNames(h, MAKEINTRESOURCE(3));
            Console.WriteLine("RT_GROUP_ICON count=" + groupIcons.Count);
            for (int i = 0; i < groupIcons.Count; i++) Console.WriteLine("  " + groupIcons[i]);
            Console.WriteLine("RT_ICON count=" + icons.Count);
            for (int i = 0; i < icons.Count; i++) Console.WriteLine("  " + icons[i]);
        }
        finally
        {
            FreeLibrary(h);
        }
    }
}
