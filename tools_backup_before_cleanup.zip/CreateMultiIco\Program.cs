using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: CreateMultiIco <source-image-or-ico> <output-ico>");
            return;
        }
        string src = args[0];
        string dst = args[1];
        if (!File.Exists(src)) { Console.WriteLine("Source not found: " + src); return; }

        try
        {
            // Attempt to load best source bitmap. If source is ICO, extract largest frame.
            Bitmap baseBmp = null;
            try
            {
                using (var fs = new FileStream(src, FileMode.Open, FileAccess.Read))
                {
                    using (var icon = new Icon(fs))
                    {
                        // try to get largest reasonable size
                        int[] trySizes = new int[] {256,128,64,48,32,16};
                        foreach (int s in trySizes)
                        {
                            try
                            {
                                Icon i2 = new Icon(fs);
                                // new Icon(fs, size) doesn't work on same stream; instead recreate
                            }
                            catch { }
                        }
                    }
                }
            }
            catch
            {
                // ignore
            }

            // Simple approach: load as bitmap (works for ICO too but gives default size)
            using (Image img = Image.FromFile(src))
            {
                baseBmp = new Bitmap(img.Width, img.Height, PixelFormat.Format32bppArgb);
                using (Graphics g = Graphics.FromImage(baseBmp))
                {
                    g.Clear(Color.Transparent);
                    g.CompositingMode = CompositingMode.SourceOver;
                    g.CompositingQuality = CompositingQuality.HighQuality;
                    g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    g.SmoothingMode = SmoothingMode.HighQuality;
                    g.DrawImage(img, 0, 0, img.Width, img.Height);
                }
            }

            int[] sizes = new int[] {256,128,64,48,32,16};
            var pngs = new List<byte[]>();
            foreach (int s in sizes)
            {
                using (Bitmap bmp = new Bitmap(s, s, PixelFormat.Format32bppArgb))
                {
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.Clear(Color.Transparent);
                        g.CompositingMode = CompositingMode.SourceOver;
                        g.CompositingQuality = CompositingQuality.HighQuality;
                        g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                        g.SmoothingMode = SmoothingMode.HighQuality;
                        g.DrawImage(baseBmp, 0, 0, s, s);
                    }
                    using (var ms = new MemoryStream())
                    {
                        // Save as PNG inside ICO for true alpha support
                        bmp.Save(ms, ImageFormat.Png);
                        pngs.Add(ms.ToArray());
                    }
                }
            }

            using (var outFs = new FileStream(dst + ".tmp", FileMode.Create, FileAccess.Write))
            using (var bw = new BinaryWriter(outFs))
            {
                // ICONDIR
                bw.Write((ushort)0); // reserved
                bw.Write((ushort)1); // type 1 = ICO
                bw.Write((ushort)pngs.Count);

                int headerSize = 6 + 16 * pngs.Count;
                int offset = headerSize;
                for (int i = 0; i < pngs.Count; i++)
                {
                    byte size = (byte)(sizes[i] >= 256 ? 0 : sizes[i]);
                    bw.Write(size); // width
                    bw.Write(size); // height
                    bw.Write((byte)0); // color count
                    bw.Write((byte)0); // reserved
                    bw.Write((ushort)1); // planes (usually ignored for PNG)
                    bw.Write((ushort)32); // bit count
                    bw.Write((uint)pngs[i].Length); // bytes in resource
                    bw.Write((uint)offset); // image offset
                    offset += pngs[i].Length;
                }

                // Write image data
                for (int i = 0; i < pngs.Count; i++)
                {
                    bw.Write(pngs[i]);
                }
                bw.Flush();
            }

            // Replace destination
            if (File.Exists(dst)) File.Delete(dst);
            File.Move(dst + ".tmp", dst);
            Console.WriteLine("Wrote: " + dst);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }
}
