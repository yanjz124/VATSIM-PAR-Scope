using System;
using System.IO;
using System.Runtime.InteropServices;

class Program
{
    const UInt32 RT_ICON = 3;
    const UInt32 RT_GROUP_ICON = 14;

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern IntPtr BeginUpdateResource(string pFileName, bool bDeleteExistingResources);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool UpdateResource(IntPtr hUpdate, IntPtr lpType, IntPtr lpName, ushort wLanguage, byte[] lpData, uint cbData);

    [DllImport("kernel32.dll", SetLastError = true)]
    static extern bool EndUpdateResource(IntPtr hUpdate, bool fDiscard);

    static IntPtr MAKEINTRESOURCE(int id) { return new IntPtr(id); }

    static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: EmbedIcon <exe> <ico>");
            return;
        }
        string exe = args[0];
        string ico = args[1];
        if (!File.Exists(exe)) { Console.WriteLine("Exe not found: " + exe); return; }
        if (!File.Exists(ico)) { Console.WriteLine("Ico not found: " + ico); return; }

        byte[] icoBytes = File.ReadAllBytes(ico);
            using (var br = new BinaryReader(new MemoryStream(icoBytes)))
            {
                Console.WriteLine("ICO length=" + icoBytes.Length);
            // Read ICONDIR
            ushort reserved = br.ReadUInt16();
            ushort type = br.ReadUInt16();
            ushort count = br.ReadUInt16();
                Console.WriteLine("Parsed ICONDIR reserved=" + reserved + " type=" + type + " count=" + count);
            if (reserved != 0 || (type != 1 && type != 2)) { Console.WriteLine("Not a valid ICO/CUR file"); return; }

            var entries = new IconEntry[count];
            for (int i = 0; i < count; i++)
            {
                entries[i] = new IconEntry();
                entries[i].Width = br.ReadByte();
                entries[i].Height = br.ReadByte();
                entries[i].ColorCount = br.ReadByte();
                entries[i].Reserved = br.ReadByte();
                entries[i].Planes = br.ReadUInt16();
                entries[i].BitCount = br.ReadUInt16();
                entries[i].BytesInRes = br.ReadUInt32();
                entries[i].ImageOffset = br.ReadUInt32();
            }

            IntPtr hUpdate = BeginUpdateResource(exe, false);
            if (hUpdate == IntPtr.Zero) { Console.WriteLine("BeginUpdateResource failed: " + Marshal.GetLastWin32Error()); return; }

            try
            {
                Console.WriteLine("Attempting to write " + count + " images into exe");
                // Write each image to RT_ICON with ids starting at 1
                for (int i = 0; i < count; i++)
                {
                    br.BaseStream.Seek(entries[i].ImageOffset, SeekOrigin.Begin);
                    byte[] img = br.ReadBytes((int)entries[i].BytesInRes);
                    Console.WriteLine(string.Format("Entry[{0}] offset={1} bytes={2}", i, entries[i].ImageOffset, entries[i].BytesInRes));
                    int id = i + 1;
                    bool ok = UpdateResource(hUpdate, MAKEINTRESOURCE((int)RT_ICON), MAKEINTRESOURCE(id), 0, img, (uint)img.Length);
                    if (!ok) { Console.WriteLine("UpdateResource RT_ICON failed for id " + id + " err=" + Marshal.GetLastWin32Error()); }
                    else Console.WriteLine("Wrote RT_ICON id=" + id + " size=" + img.Length);
                }

                // Build GRPICONDIR
                using (var ms = new MemoryStream())
                using (var bw = new BinaryWriter(ms))
                {
                    bw.Write((ushort)0); // reserved
                    bw.Write((ushort)1); // type
                    bw.Write((ushort)count);
                    for (int i = 0; i < count; i++)
                    {
                        bw.Write(entries[i].Width);
                        bw.Write(entries[i].Height);
                        bw.Write(entries[i].ColorCount);
                        bw.Write(entries[i].Reserved);
                        bw.Write(entries[i].Planes);
                        bw.Write(entries[i].BitCount);
                        bw.Write(entries[i].BytesInRes);
                        bw.Write((ushort)(i + 1)); // resource id
                    }
                    bw.Flush();
                    byte[] grp = ms.ToArray();
                    bool ok2 = UpdateResource(hUpdate, MAKEINTRESOURCE((int)RT_GROUP_ICON), MAKEINTRESOURCE(1), 0, grp, (uint)grp.Length);
                    if (!ok2) { Console.WriteLine("UpdateResource RT_GROUP_ICON failed: " + Marshal.GetLastWin32Error()); }
                    else Console.WriteLine("Wrote RT_GROUP_ICON (count=" + count + ")");
                }
            }
            finally
            {
                if (!EndUpdateResource(hUpdate, false))
                {
                    Console.WriteLine("EndUpdateResource failed: " + Marshal.GetLastWin32Error());
                }
            }
        }

    }

    class IconEntry
    {
        public byte Width;
        public byte Height;
        public byte ColorCount;
        public byte Reserved;
        public ushort Planes;
        public ushort BitCount;
        public uint BytesInRes;
        public uint ImageOffset;
    }
}
