using System;
using System.Drawing;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length < 2)
        {
            Console.WriteLine("Usage: ExtractExeIcon <exe-path> <out-ico>");
            return;
        }
        string exePath = args[0];
        string outIco = args[1];
        if (!File.Exists(exePath)) { Console.WriteLine("Executable not found: " + exePath); return; }
        try
        {
            Icon icon = Icon.ExtractAssociatedIcon(exePath);
            if (icon == null) { Console.WriteLine("No icon extracted."); return; }
            using (var fs = new FileStream(outIco, FileMode.Create))
            {
                icon.Save(fs);
            }
            Console.WriteLine("Extracted icon to: " + outIco);
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error: " + ex.Message);
        }
    }
}
