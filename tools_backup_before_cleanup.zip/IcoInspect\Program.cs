using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length == 0) { Console.WriteLine("Usage: IcoInspect <ico-file>"); return; }
        string path = args[0];
        if (!File.Exists(path)) { Console.WriteLine("File not found: " + path); return; }
        using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read))
        {
            using (var icon = new Icon(fs))
            {
                Console.WriteLine("Loaded Icon: " + path);
            }
        }
        // More detailed: parse ICO headers
        using (var br = new BinaryReader(File.OpenRead(path)))
        {
            var reserved = br.ReadUInt16();
            var type = br.ReadUInt16();
            var count = br.ReadUInt16();
            Console.WriteLine(string.Format("Reserved={0}, Type={1}, Count={2}", reserved, type, count));
            for (int i = 0; i < count; i++)
            {
                byte width = br.ReadByte();
                byte height = br.ReadByte();
                byte colorCount = br.ReadByte();
                byte reservedByte = br.ReadByte();
                ushort planes = br.ReadUInt16();
                ushort bitCount = br.ReadUInt16();
                uint bytesInRes = br.ReadUInt32();
                uint imageOffset = br.ReadUInt32();
                Console.WriteLine(string.Format("Entry[{0}]: {1}x{2}, colorCount={3}, planes={4}, bitCount={5}, bytes={6}, offset={7}", i, width, height, colorCount, planes, bitCount, bytesInRes, imageOffset));
                long pos = br.BaseStream.Position;
                br.BaseStream.Seek(imageOffset, SeekOrigin.Begin);
                byte[] header = br.ReadBytes(8);
                // Check for PNG header (89 50 4E 47 0D 0A 1A 0A)
                bool isPng = header.Length >= 8 && header[0]==0x89 && header[1]==0x50 && header[2]==0x4E && header[3]==0x47;
                Console.WriteLine(string.Format("  IsPNG={0}", isPng));
                br.BaseStream.Seek(pos, SeekOrigin.Begin);
            }
        }
    }
}
